﻿//Медведская Мария Ильинична
//БПИ-246
//Вариант 10

using System;
using System.IO;


/// <summary>
/// Проект, создающий одномерный массив и рамещает в них данные, прочитанные из текстового файла input.txt.
/// </summary>
class Project_mod1
{
    /// <summary>
    /// Точка входа в программу.
    /// </summary>
    public static void Main()
    {
        ConsoleKeyInfo keyToExit;

        do
        {
            //Ввод параметров a,b,c,d с клавиатуры и проверка корректности ввода (0<параметр<1).
            float a;
            Console.WriteLine("Введите параметр a (от 0 до 1)");
            while (!(float.TryParse(Console.ReadLine(), out a) && (a > 0 && a < 1)))
            {
                Console.WriteLine("Параметр a введен некорректно");
                Console.WriteLine(("Введите параметр a еще раз"));
            }

            float b;
            Console.WriteLine("Введите параметр b (от 0 до 1)");
            while (!(float.TryParse(Console.ReadLine(), out b) && (b > 0 && b < 1)))
            {
                Console.WriteLine("Параметр b введен некорректно");
                Console.WriteLine(("Введите параметр b еще раз"));
            }

            float c;
            Console.WriteLine("Введите параметр c (от 0 до 1)");
            while (!(float.TryParse(Console.ReadLine(), out c) && (c > 0 && c < 1)))
            {
                Console.WriteLine("Параметр c введен некорректно");
                Console.WriteLine(("Введите параметр c еще раз"));
            }

            float d;
            Console.WriteLine("Введите параметр d (от 0 до 1)");
            while (!(float.TryParse(Console.ReadLine(), out d) && (d > 0 && d < 1)))
            {
                Console.WriteLine("Параметр d введен некорректно");
                Console.WriteLine(("Введите параметр d еще раз"));
            }


            try
            {
                string path = @"../../../../input.txt";
                string[] lines = File.ReadAllLines(path); //Массив из строк файла. 
                string[] x = lines[0].Split(' '); //Получение массива x из первой строки файла. 
                string[] y = lines[1].Split(' '); //Получение массива y из второй строки файла.                         
                if (x.Length == y.Length)
                {
                    string s = "";  //В s добавляются значения sk. 
                    int count = 0; //Счетчик кол-ва значений sk в файле. 
                    for (int i = 0; i < x.Length; i++)
                    {
                        if ((int.TryParse(x[i], out int xk)) && (int.TryParse(y[i], out int yk)))
                        {
                            double sk = GetSk(a, b, c, d, xk, yk); //Вычисление sk по формуле из метода. 
                            count += 1;
                            s = $"{s}" + $"{sk}\n";
                        }
                        File.WriteAllText(@"../../../../output.txt", s); 

                    }

                    if (count == 0)        //Если счетчик нулевой, то корректных данных в файле нет. 
                    {
                        Console.WriteLine("Корректных данных в файле нет");
                        Console.WriteLine("Попробуйте повторить решение сначала");
                    }
                }
                else
                {
                    File.WriteAllText(@"../../../../output.txt", "0");  //Запись нуля при неравном кол-ве эл-ментов в массивах. 
                }
            }
            catch (DivideByZeroException) //Выдает сообщение при попытке деления на ноль. 
            {
                Console.WriteLine("Во время выполнения программы была попытка деления на ноль");
                Console.WriteLine("P.S. Попробуйте изменить коэффициенты c или d");
            }
            catch (FileNotFoundException) //Исключение, связанное с открытием файла. 
            {
                Console.WriteLine("Проблемы с открытием файла");
            }
            catch (DirectoryNotFoundException) //Исключение, связанное с открытием файла. 
            {
                Console.WriteLine("Проблемы с открытием файла");
            }
            catch (IOException) //Исключение, связанное с чтением файла. 
            {
                Console.WriteLine("Проблемы с чтением данных из файла");
            }
            catch (OverflowException e)  //Слишком большая длина массива. 
            {
                Console.WriteLine(e.Message);
            }
                
            
            finally
            {
                Console.WriteLine("Для выхода нажмите Escape");
                keyToExit = Console.ReadKey(true);
            }

        } while (keyToExit.Key != ConsoleKey.Escape); //Выход из программы по клавише escape. 
    }


    /// <summary>
    /// Метод, вычисляющий значение для элементов k по формуле S(k)=((a * x(k) + b) / (c * y(k) + d)). 
    /// </summary>
    /// <param name="a">Параметр a</param>
    /// <param name="b">Параметр b</param>
    /// <param name="c">Параметр c</param>
    /// <param name="d">Параметр b</param>
    /// <param name="xk">k-тое значение массива X</param>
    /// <param name="yk">k-тое значение массива Y</param>
    /// <returns>Значение S(k)</returns>
    private static double GetSk(float a, float b, float c, float d, int xk, int yk) => ((a * xk + b) / (c * yk + d));

    
}


    
